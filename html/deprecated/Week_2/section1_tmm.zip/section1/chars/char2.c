#include <stdio.h>

int main(int argc, char* argv[]) {
    // create new array
    char letters[5] = { 'm', 'a', 'l', 'a', 'n' };

    // ah... asciitable.com never fails
    printf("%d\n", (int) (letters[1] + 1));
}
