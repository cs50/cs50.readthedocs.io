#include <cs50.h>
#include <stdio.h>

int fs (int num);

int
main (int argc, char* argv[])
{
    printf("Int, pl0x:\n");
    int numba = GetInt();
    
    int ret = fs(numba);
    printf("Returned: %d\n", ret);
}

int
fs (int num)
{
    printf("^_^\n");

    if(num == 0)
        return 0;
    else if (num == 1)
        return 1;
    else
        return (fs(num-1) + fs(num-2));
}
