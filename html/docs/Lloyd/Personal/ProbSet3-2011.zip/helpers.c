/**************************************************************************** 
 * helpers.c
 *
 * Doug Lloyd
 * September 28, 2011
 *
 * Helper functions for Problem Set 3.
 ***************************************************************************/
       
#include <cs50.h>
#include "helpers.h"


/*
 * Returns true if value is in array of n values, else false.
 */

bool search(int value, int array[], int n) {
  return binarysearch(value, array, 0, n-1);
}

/*
 * Helper function for search() - recursively does binary search
 */

bool binarysearch(int value, int array[], int start, int end) {

  /* If this happens, element not in the array */
  if(start > end)
    return false;

  /* Calculate the midpoint */
  int mid = (start + end) / 2;

  /* If target is at the midpoint, we found it */
  if(array[mid] == value)
    return true;

  /* If target is greater than midpoint, we need to search to the right */
  else if(array[mid] < value)
    return binarysearch(value, array, mid+1, end);

  /* If target is less than the midpoint, we need to search to the left */
  else
    return binarysearch(value, array, start, mid-1);
}

/*
 * Sorts array of n values.
 */

void sort(int values[], int n) {

  /* Implementing selection sort */
  for(int i = 0; i < n; i++) {

    /* Set the index of the smallest element to be the first element */
    int smallest = i;
    int j;
    for(j = i; j < n; j++) {

      /* If we find a smaller element, set smallest to reference that one */
      if(values[j] < values[smallest])
	smallest = j;
    }

    /* After searching unsorted portion, swap current element with smallest */
    swap(&values[i], &values[smallest]);
  }

  return;
}

/*
 * Swapping function
 */

void swap(int *a, int *b) {
  /* Same as a regular swap, except we have pointers, so we're swapping the
     actual values, not copies of them */
  int tmp = *a;
  *a = *b;
  *b = tmp;
  return;
}
