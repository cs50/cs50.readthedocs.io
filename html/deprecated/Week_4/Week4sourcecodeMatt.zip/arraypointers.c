/******************************************************************************
 * arraypointers.c
 * Matthew Chartier
 * CS50/CSCI E-52, Fall 2010
 *
 * Demonstration of arrays as pointers.
 *****************************************************************************/

#include <stdio.h>

int
main(int argc, char *argv[])
{
    int squares[10] = {0, 1, 4, 9, 16, 25, 36, 49, 64, 81};
    
    printf("Now check this out...\n");
    
    for(int i = 0; i < 10; i++)
    {
        printf("squares[%d] == %2d", i, squares[i]);
        printf("        ");
        printf("*(squares + %d) == %2d", i, *(squares + i));
        printf("\n");
    }
}
