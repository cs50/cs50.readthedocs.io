#include <stdio.h>

int
main(int argc, char *argv[])
{
    int a = 3;
    int *pa = &a;
    
    printf("The value of a is now %d\n", a);
    printf("The value of &a is now 0x%x\n", (unsigned int) &a);
    printf("The value of pa is now 0x%x\n", (unsigned int) pa);
    printf("The value of *pa is now %d\n", *pa);

    printf("\n");
    *pa = 4;

    printf("The value of a is now %d\n", a);
    printf("The value of &a is now 0x%x\n", (unsigned int) &a);
    printf("The value of pa is now 0x%x\n", (unsigned int) pa);
    printf("The value of *pa is now %d\n", *pa);

    return 0;
}
