/******************************************************************************
 * checkwork.c
 * Matthew Chartier
 * CS50/CSCI E-52, Fall 2010
 *
 * Print out answers to pointer exercise. Hope we didn't mess up!
 *****************************************************************************/

#include <stdio.h>

int a = 3, b = 4, c = 5;
int *pa = &a;
int *pb = &b;
int *pc = &c;

char* p_str[3];

void
update_strings()
{
    int* ptr;
    for(int i = 0; i < 3; i++)
    {
	if(i == 0)
	    ptr = pa;
	else if(i == 1)
	    ptr = pb;
	else
	    ptr = pc;
	if(ptr == &a)
	    p_str[i] = "&a";
        else if(ptr == &b)
	    p_str[i] = "&b";
        else if(ptr == &c)
	    p_str[i] = "&c";
        else
	    p_str[i] = "ERROR";
    }   
}

void
print_row(void)
{
    printf("%d\t%d\t%d\t%s\t%s\t%s\n", a, b, c, p_str[0], p_str[1], p_str[2]);
}

int
main(void)
{
    printf("a\tb\tc\tpa\tpb\tpc\n");
    
    a = b*c;
    update_strings();


    a *= c;
    update_strings();
    print_row();

    b = *pa;
    update_strings();
    print_row();

    pc = pa;
    update_strings();
    print_row();

    *pb = b * c;
    update_strings();
    print_row();

    c = (*pa) * (*pc);
    update_strings();
    print_row();

    *pc = a * (*pb);
    update_strings();
    print_row();
}
