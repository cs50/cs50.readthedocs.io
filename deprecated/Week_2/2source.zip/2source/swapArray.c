/**********************************************
*  Swapping numbers using an array.           * 
*                                             *
*  Shows that passing an array as a parameter * 
*  is pass-by-reference, not pass-by-value.   *
***********************************************/

#include <cs50.h>
#include <stdio.h>

void swap(int vals[]); //function declaration

int
main (void)
{
    int nums[2] = {4, 2}; //numbers to swap
    
    printf("Before x: %d, y: %d\n", nums[0], nums[1]);
    swap(nums);
    printf("After x: %d, y: %d\n", nums[0], nums[1]);
}

void
swap (int vals[])
{
    int temp = vals[0];
    vals[0] = vals[1];
    vals[1] = temp;
}
