/*********************************
*  Swapping numbers by using     * 
*  global variables.             *
*  No parameter passing needed.  *
*********************************/

#include <cs50.h>
#include <stdio.h>

int x, y; // globals

void swap (void);

int
main (void)
{
    x = 4;
    y = 2;

    printf("Before x: %d, y: %d\n", x, y);
    swap();
    printf("After x: %d, y: %d\n", x, y);
}

void
swap (void)
{
    int temp = x;
    x = y;
    y = temp;
}
