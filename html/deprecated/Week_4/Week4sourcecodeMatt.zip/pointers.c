/******************************************************************************
 * pointers.c
 * Matthew Chartier
 * CS50/CSCI E-52, Fall 2010
 *
 * Pointer Fun.
 *****************************************************************************/

#include <stdio.h>
#include <cs50.h>

int
main(int argc, char *argv[])
{

    // declare a pointer
    int *p;
    
    // declare a variable of the same type
    int x;
    
    // give x some value
    x = 42;
    
    // make p point to the value represented by x
    p = &x;
    
    // change the value which is pointed to by p
    *p = 9001;
    
    // see the results
    printf(" x: %d\n", x);
    printf("*p: %d\n", *p);
}
