/****************************************
 * binary1.c
 *
 * October 24, 2010
 * Doug Lloyd
 *
 * Binary trees
 ****************************************/

#include "binary.h"
#include <stdio.h>
#include <stdlib.h>

int main() {
  tree one, two, three, four, five, six, seven;

  // Set the branches; four is the root
  four.left = &two;
  four.right = &six;
  two.left = &one;
  two.right = &three;
  six.left = &five;
  six.right = &seven;

  // Set the remaining nodes to be leaves
  one.left = NULL;
  one.right = NULL;
  three.left = NULL;
  three.right = NULL;
  five.left = NULL;
  five.right = NULL;
  seven.left = NULL;
  seven.right = NULL;

  // Set the data
  one.data = 1;
  two.data = 2;
  three.data = 3;
  four.data = 4;
  five.data = 5;
  six.data = 6;
  seven.data = 7;

  printtree(&four);
  return 0;
}

void printtree(tree *root) {
  printf("In order: ");
  printtreeinorder(root);
  printf("\nShowing parents: \n\n");
  printtreeshowparents(root, 0);
  printf("\n");
  return;
}

void printtreeinorder(tree *root) {
  if(root == NULL)
    return;
  else {
    printtreeinorder(root->left);
    printf("%d ", root->data);
    printtreeinorder(root->right);
  }
  return;
}

void printtreeshowparents(tree *root, int padding) {
  if(root == NULL)
    return;
  else {
    for(int i = 0; i < padding; i++)
      printf(" ");
    if(root->left == NULL && root->right == NULL)
      printf("(%d)\n", root->data);
    else
      printf("%d\n", root->data);
    printtreeshowparents(root->left, padding + 4);
    printtreeshowparents(root->right, padding + 4);
  }
  return;
}
