/********************************************* 
*  A program that illustrates methods to     *
*  cast from char to (ASCII) int and back.   *
*********************************************/

#include <cs50.h>
#include <stdio.h>

int
main (void)
{
    char letr = 'a';
    int a_ascii = (int) 'a';
    
    printf("%c in ASCII is %d, right?\n", letr, a_ascii);
    
    printf("Explicit cast: %d\n", a_ascii);
    printf("Letter: %d\n", 'a');
    printf("Number: %c\n", 97);

    printf("Adding 2: %c\n", ('a' + 2));    

}
