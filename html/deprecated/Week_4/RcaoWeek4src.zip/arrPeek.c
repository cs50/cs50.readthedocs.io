/***************************************************
*   Asks for either a string or ints,
*   depending on command-line argument,
*   and lets user peek into indices, their 
*   contents, and addresses.
*
*   Elements and indices are printed as a table
*   for convenience.
*
*   Good for showing pointer arithmetic for 
*   different variable types (well, int vs. char).
*
**********************************************@};~*/

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

#define MAX_INTS 100
#define INT 0
#define STR 1

int checkType(char* arg);

int
main(int argc, char *argv[])
{
    // Check for command-line argument
    if (argc != 2)
    {
        printf("\033[31mUsage: ./arrPeek dataType\n\033[39m");
        return 1;
    }
    
    int type = checkType(argv[1]);
    // Sanity check
    if (type < 0)
        return 2;
    
    printf("ohai, i can has stuhffz?\n");
    int length;
    char* str;
    int arrNum[MAX_INTS];
        
    if (type == STR)
    {
        str = GetString();    
        length = strlen(str);
    }
    else if (type == INT)
    {
        for (length = 0; length < MAX_INTS; length++)
        {
            int curr;
            do
            {
                printf("Int[%d]: ", length);
                curr = GetInt();
            } while (curr > 99 && curr != INT_MAX);
            // Restrict input for pretty formatting
    
            // ctrl+d = end
            if (curr == INT_MAX)
                break;
            arrNum[length] = curr;
        }
        printf("\n");
    }    
    
    // Print time!
    printf("len = %d\n\n", length);  
    char* typ = (type == INT) ? "arrNum" : "str";
    printf("here iz ur stuhffz, called \"%s\":\n", typ);
    
    // Print the array indices--with color! (If I remember...)
    // TODO: make a draw() function to redraw when desired
    printf(" Index: ");
    for(int place=0; place<length; place++)
    {
        printf("\033[34m|\033[37m%2d ",place);
    }
    printf("\033[34m|\033[37m\n");

    
    // Print the array contents
    
    printf("\033[33m%6s: \033[39m", typ);
    for(int spotz = 0 ; spotz<length; spotz++)
    {
        if (type == STR)
            printf("\033[34m|\033[33m%2c ", str[spotz]);   
        else if (type == INT)
            printf("\033[34m|\033[33m%2d ", arrNum[spotz]);           
    }
    printf("\033[34m|\033[37m\n");
    
    int index;
    while(1)
    {
        do
        {
            printf("Which index would you like to access?\n");
            index = GetInt();
        } 
        while(index>=length);
       
        printf("index = \033[36m%d\n\033[39m", index);
        
        if (type == STR)
        {
            printf("str = \033[36m%p\n\033[39m", str);
            printf("str + index = \033[36m%p\n\033[39m", str + index);
            printf("*(str + index) = \033[36m%c\n\033[39m", *(str + index));
            printf("str[index] = \033[36m%c\n\033[39m", str[index]);    
        }
        else if (type == INT)
        {
            printf("arrNum = \033[36m%p\n\033[39m", arrNum);
            printf("arrNum + index = \033[36m%p\n\033[39m", arrNum + index);
            printf("*(arrNum + index) = \033[36m%d\n\033[39m", *(arrNum + index));
            printf("arrNum[index] = \033[36m%d\n\033[39m", arrNum[index]); 
        }
        printf("\n");
    }


}

// Checks cmd-line arg to see if user wants int or char array
int
checkType(char* arg)
{
    if(tolower(arg[0]) == 'i')
        return INT;
    else if (tolower(arg[0]) == 's')
        return STR;
    else
        return -1; //nonsensical val
}
