/****************************************
 * valtest4.c
 * 
 * October 24, 2010
 * Doug Lloyd
 *
 * More valgrind failings
 ****************************************/

#include "sllist.h"
#include <stdlib.h>
#include <stdio.h>

int main() {
  sllist *list_head = llist_create(1);

  for(int i = 2; i <= 10; i++)
    list_head = llist_append(list_head, i);

  sllist *insert_node = llist_find(list_head, 5);
  llist_insert_after(insert_node, 11);

  // Let's just free the head and see what happens
  free(list_head);

  return 0;
}

sllist *llist_find(sllist *head, int val) {
  while(head != NULL) {
    if(head->data == val)
      return head;
    head = head->next;
  }

  return head;
}
  
sllist *llist_create(int val) {
  sllist *head = malloc(sizeof(sllist));
  if(head == NULL) {
    printf("Error! malloc() failure!\n");
    exit(1);
  }
  
  head->data = val;
  
  return head;
}

bool llist_insert_after(sllist *x, int val) {
  sllist *new_ele = malloc(sizeof(sllist));
  if(new_ele == NULL)
    return false;
  
  new_ele->data = val;
  
  new_ele->next = x->next;
  x->next = new_ele;

  return true;
}

sllist *llist_append(sllist *head, int val) {
  sllist *trav = head;
  while(trav->next != NULL)
    trav = trav->next;

  trav->next = malloc(sizeof(sllist));
  if(trav->next == NULL) {
    printf("Failure to append node to list!\n");
    return head;
  }

  trav->next->data = val;
  trav->next->next = NULL;
  
  return head;
}

void llist_destroy_list(sllist *head) {
  if(head == NULL)
    return;
  else {
    llist_destroy_list(head->next);
    free(head);
  }
  return;
}

void printList_R(sllist *head) {
  if(head == NULL)
    return;
  else {
    printf("%d ", head->data);
    printList_R(head->next);
  }
  return;
}
