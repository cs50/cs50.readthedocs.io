/*****************************************************************************
 * malloc.c
 * Matthew Chartier
 * CS50/CSCI E-52, Fall 2010
 *
 * Dynamic memory allocation using malloc.
 ****************************************************************************/
 
#include <stdio.h>
#include <cs50.h>
#include <stdlib.h>
 
int
main(int argc, char *argv[])
{
    // what are we getting here?
    int *p = malloc(10 * sizeof(int));

    // sanity check
    if (p == NULL)
    {
        printf("Unable to allocate memory.\n");
        return 1;
    }    

    // investigate contents of memory
    for(int i = 0; i < 10; i++)
    {
        p[i] = i + 1;
        printf("p[%d] == %d\n", i, p[i]); 
    }
    
    // free up memory which we allocated
    free(p);

    return 0;
} 
