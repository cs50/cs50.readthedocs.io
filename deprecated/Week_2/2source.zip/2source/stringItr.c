/*********************************************
*  Shows ways to iterate across a string,    *
*  specifically using strlen() and the null  *
*  terminator ('\0').                        *
*                                            *
*  Which is more efficient? Why?             *
**********************************************/

#include <cs50.h>
#include <stdio.h>
#include <string.h>

int
main (void)
{
    string str = "This is CS50.";
    
    // Get the string length, print for reference
    int len = strlen(str);
    printf("(The string's length is %d.)\n\n", len);
    
    // Iterate using string length, print
    for(int i = 0; i < len; i++)
    {
        printf("%c", str[i]);
    }
    
    printf("\n\n(Naos...null char time.)\n\n");
    
    // Iterate using null char, print
    for(int i = 0; str[i]!= '\0'; i++)
    {
        printf("%c", str[i]);
    }
    
    printf("\n\nThey're the same, right?!\n");

}
