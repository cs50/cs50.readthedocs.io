<?php
if (!isset($_POST['word0']))
{
    header("Location: madlibs.php");
}
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Madlibs</title>
    </head>
    <body>
    <p>CS50 is a <?php echo $_POST['word0']; ?> course. The <?php echo $_POST['word1']; ?>, David Malan, is very <?php echo $_POST['word2']; ?>. All <?php echo $_POST['word3']; ?> should take CS50 before they <?php echo $_POST['word4']; ?>.</p>
    </body>
</html>
