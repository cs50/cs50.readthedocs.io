#include <stdio.h>
#include "cs50.h"

//global variables
float x, y;

//function declarations
void reader(void);
float avg (void); 

int main()
{
    //function calls
    avg();
    printf("\n Average: %f \n", avg());
}
       
void reader()
{
    printf("\n Give me an x:");
    x = GetFloat();
    
    printf("\n Give me a y:");
    y = GetFloat();
}
    
float avg()
{
    reader();
    return (x+y) / 2.;
}
