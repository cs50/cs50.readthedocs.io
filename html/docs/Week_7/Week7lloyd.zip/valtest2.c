/*************************************
 * valtest2.c
 *
 * Doug Lloyd
 * October 24, 2010
 *
 * Will fail a valgrind check
 *************************************/

#include <stdio.h>
#include <stdlib.h>

int main() {
  int *x;
  for(int i = 0; i < 10; i++) {
    x = malloc(sizeof(int));
    *x = i;
  }
  return 0;
}
