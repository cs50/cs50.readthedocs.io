/***************************************************************************
 * fifteen.c
 *
 * Doug Lloyd
 * September 28, 2011
 *
 * Implements The Game of Fifteen (generalized to d x d).
 *
 * Usage: fifteen d
 * whereby the board's dimensions are to be d x d,
 * where d must be in [DIM_MIN,DIM_MAX]
 ***************************************************************************/
 
#define _XOPEN_SOURCE 500

// header files
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

// constants
#define DIM_MIN 3
#define DIM_MAX 9
#define BLANK 0

// board
int board[DIM_MAX][DIM_MAX];

// dimensions
int d;


// prototypes
void clear(void);
void greet(void);
void init(void);
void draw(void);
bool move(int tile);
int dist(int x1, int y1, int x2, int y2);
bool won(void);
void swap(int *a, int *b);

int main(int argc, char **argv) {
    // greet user with instructions
    greet();

    // ensure proper usage
    if (argc != 2) {
        printf("Usage: %s d\n", argv[0]);
        return 1;
    }

    // ensure valid dimensions
    d = atoi(argv[1]);
    if (d < DIM_MIN || d > DIM_MAX) {
      printf("Board must be between %d x %d and %d x %d, inclusive.\n",
	     DIM_MIN, DIM_MIN, DIM_MAX, DIM_MAX);
      return 2;
    }
    
    // initialize the board
    init();

    // accept moves until game is won
    while (true) {
      // clear the screen
      clear();
      
      // draw the current state of the board
      draw();
	
      // check for win
      if (won()) {
	printf("ftw!\n");
	break;
      }
      
      // prompt for move
      printf("Tile to move: ");
      int tile = GetInt();
      
      // move if possible, else report illegality
      if (!move(tile)) {
	printf("\nIllegal move.\n");
	usleep(50000);
      }
      
      // sleep thread for animation's sake
      usleep(50000);
    }
    
    // that's all folks
    return 0;
}

/*
 * Clears screen using ANSI escape sequences.
 */

void clear(void) {
    printf("\033[2J");
    printf("\033[%d;%dH", 0, 0);
}

/*
 * Greets player.
 */

void greet(void) {
    clear();
    printf("WELCOME TO THE GAME OF FIFTEEN\n");
    usleep(500000);
}

/*
 * Initializes the game's board with tiles numbered 1 through d*d - 1
 * (i.e., fills 2D array with values but does not actually print them).  
 */

void init(void) {

  // General case
  int sqnum = (d*d)-1;
  for(int i = 0; i < d; i++)
    for(int j = 0; j < d; j++, sqnum--)
      board[i][j] = sqnum;

  // Special case for even-numbered boards
  if(!(d%2))
    swap(&board[d-1][d-2], &board[d-1][d-3]);
  
  // All done
  return;
}

/* 
 * Prints the board in its current state.
 */

void draw(void) {

  // cycle through cells, print numbers if nonzero
  for(int i = 0; i < d; i++) {
    for(int j = 0; j < d; j++)
      (board[i][j] == BLANK) ? printf("  _") : printf("%3d", board[i][j]);
    printf("\n\n");
  }
  return;
}

/* 
 * If tile borders empty space, moves tile and returns true, else
 * returns false. 
 */

bool move(int tile) {
  
  // Find tile location and blank location
  int tilerow, tilecol, blankrow, blankcol;
  for(int i = 0; i < d; i++)
    for(int j = 0; j < d; j++) {
      if(board[i][j] == tile) {
	tilerow = i;
	tilecol = j;
      }
      if(board[i][j] == BLANK) {
	blankrow = i;
	blankcol = j;
      }
    }

  // Calculate distance between them; if dist == 1 then the squares are
  // adjacent and can be swapped. Otherwise, they can't.

  if(dist(tilerow, tilecol, blankrow, blankcol) == 1) {
    swap(&board[tilerow][tilecol], &board[blankrow][blankcol]);
    return true;
  }
  return false;
}

/*
 * Calculates the distance (taxicab geometry) between two tiles
 */

int dist(int x1, int y1, int x2, int y2) {
  return abs((x1-x2) + (y1-y2));
}

/*
 * Returns true if game is won (i.e., board is in winning configuration), 
 * else false.
 */

bool won(void) {

  // Cycle through, checking to see if cells are in order
  int winnum = 1;
  for(int i = 0; i < d; i++)
    for(int j = 0; j < d; j++, winnum++) 
      if(board[i][j] != (winnum % (d * d)))
	return false;
  return true;
}

/*
 * Swaps two numbers given the pointers. Used in init() and move()
 */

void swap(int *a, int *b) {
  int tmp = *a;
  *a = *b;
  *b = tmp;
  return;
}
