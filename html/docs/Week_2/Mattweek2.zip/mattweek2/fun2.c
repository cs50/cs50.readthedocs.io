/*****************************************************************************
 * fun2.c
 * Matthew Chartier
 * CS50/CSCI E-52
 *
 * Uses functions to square a user-inputted int and print it nicely.
 *****************************************************************************/
 
#include <stdio.h>
#include <cs50.h>

int get_pos_int();

void pretty_print(int x);

int square(int x);

int
main (int argc, char* argv[])
{
    //Get a positive integer from the user and store it in x.
    int x = get_pos_int();
    
    //Use a function to square the value in x!
    x = square(x);
    
    //Print out our new (squared?) value fancily
    pretty_print(x);

    return 0;
}

int
get_pos_int()
{
    int x = 0;
    do
    {
        printf("Enter a positive integer: ");
        x = GetInt();
    } 
    while (x < 1);
    
    return x;
}

void
pretty_print(int x)
{
    printf("____________________________\n");
    printf("|                           |\n");
    printf("|Your number squared is: %d|\n", x);
    printf("|___________________________|\n");
}

int
square(int x)
{
    return x*x;
}

