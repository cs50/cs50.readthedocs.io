#include <stdio.h>

int main() {
  int x = 8;
  int y = 3;
  int z = 400;
  // to see if a number is odd, & it with 1. If the last bit of the integer
  // is 1 as well, then the number is odd.
  if(x & 1)
    printf("%d is odd\n", x);
  if(y & 1)
    printf("%d is odd\n", y);

  // to double a number, use a bit shift left by 1. to quadruple, bit shift
  // left by 2. You can do the opposite to divide.

  printf("%d is %d times 2\n", (y << 1), y);
  printf("%d is %d times 4\n", (y << 2), y);
  printf("%d is %d divided by 2\n", (x >> 1), x);
  printf("%d is %d divided by 4\n", (x >> 2), x);
  printf("%d is %d divided by 16\n", (z >> 4), z);
  return 0;
}
