/*******************************************
*  Program that illustrates the            *
*  priority of local and global variables. *
*******************************************/

#include <stdio.h>

int cs = 50; // Global var

int
main (void)
{
    printf("1: %d\n", cs);
    
    int cs = 17; // Local var, local to main()
    
    // Note the third cs variable, this one local to the for loop
    for (int cs = 0; cs < 1; cs++)
    {
        printf("2: %d\n", cs);
    }
    
    printf("3: %d\n", cs);
}
