// CS50
#include <cs50.h>

// structure definition
typedef struct _sllist {
  int data;
  struct _sllist *next;
} sllist;

// print a linked list iteratively
void printList_I(sllist *head);

// print a linked list recursively
void printList_R(sllist *head);

// create a linked list
sllist *llist_create(int val);

// add to the end of a linked list
sllist *llist_append(sllist *head, int val);

// add after some element in the middle of a linked list
bool llist_insert_after(sllist *x, int val);

// destroy a list
void llist_destroy_list(sllist *head);

// find an element in a linked list
sllist *llist_find(sllist *head, int val);
