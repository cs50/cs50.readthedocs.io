int
main(int argc, char *argv[])
{
    int a = 3, b = 4, c = 5;
    int *pa = &a, *pb = &b, *pc = &c;

    a = b * c;
    a *= c;
    b = *pa;
    pc = pa;
    *pb = b * c;
    c = (*pa) * (*pc);
    *pc = a * (*pb);

    return 0;
}
