/****************************
 * Problem Set 2            *
 * caesar.c                 *
 *                          *
 * Doug Lloyd               *
 * September 21, 2011       *
 ****************************/

/* Constants */
#define ALPHASIZE 26
#define LOWERBASE 'a'
#define UPPERBASE 'A'

/* Header Files */
#include <stdio.h>
#include <ctype.h>
#include <cs50.h>
#include <string.h>
#include <stdlib.h>

/* Function Declarations */
char caesarshift(char c, int shift);


/****************************/
int main(int argc, char *argv[]) {

  /* Ensure proper number of command line arguments */
  if(argc != 2) {
    printf("Usage: ./caesar <shift>\n");
    return 1;
  }

  /* Convert shift to useable form */
  int shift = atoi(argv[1]);

  /* Prompt user for string to encipher */
  printf("Plaintext: ");
  string ptxt = GetString();

  /* Execute Caesar shift on plaintext string, one character at a time */
  for(int i = 0, len = strlen(ptxt); i < len; i++) 
    printf("%c", caesarshift(ptxt[i], shift));

  /* Completed everything, print newline and exit */
  printf("\n");
  return 0;
}

char caesarshift(char c, int shift) {
  /* Change character from ASCII value to range [0-25], add the shift,
     account for wrap around, and calculate new ASCII value */
  if(islower(c))
    return ((c - LOWERBASE) + shift) % ALPHASIZE + LOWERBASE;
  else if(isupper(c))
    return ((c - UPPERBASE) + shift) % ALPHASIZE + UPPERBASE;

  /* Non alphabetic characters are unshifted */
  else
    return c;
}
