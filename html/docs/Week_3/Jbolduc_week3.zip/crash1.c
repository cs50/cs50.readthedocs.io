int
main(int argc, char *argv[])
{
    int scores[10];

    for (int i = 0; i < 10000; i++)
    {
        scores[i] = 100;
    }
}
