#include <stdio.h>

int main(int argc, char* argv[]) {
    // create new array
    int numbers[5];

    // set array contents
    // TODO: make this less awful
    numbers[0] = 0;
    numbers[1] = 1;
    numbers[2] = 2;
    numbers[3] = 3;
    numbers[4] = 4;

    // what will this print?
    printf("%d\n", numbers[2]);
}
