/*******************************************
*  Prints the characters of each of the    * 
*  command-line arguments, one per line.   *
*******************************************/

#include <cs50.h>
#include <stdio.h>
#include <string.h>

int
main (int argc, char* argv[])
{
    // To be grammatically correct
    string arg = (argc == 1) ? "argument" : "arguments";
    
    printf("You entered %d command-line %s!\nThey are:\n", argc, arg);
    
    // Iterate through the command-line strings
    for(int i = 0; i < argc; i++)
    {
        // Get length of specific string/word
        int wlen = strlen(argv[i]);
        
        // Iterate through characters of specific string/word
        for(int j = 0; j < wlen; j++)
        {
            // Print the jth char of the ith command-line argument
            printf("%c\n", argv[i][j]);
        }
        printf("\n");
    }
}
