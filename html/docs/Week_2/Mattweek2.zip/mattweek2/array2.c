/*****************************************************************************
 * array2.c
 * Matthew Chartier
 * CS50/CSCI E-52
 *
 * Declares and initializes an array of ints of length 7, then
 * scales 2nd element by 2 using a function. Note pass by reference!
 *****************************************************************************/

#include <stdio.h>
#include <cs50.h>

void
mult2by2(int numbers[])
{
    numbers[2] = numbers[2] * 2;
}

int
main(int argc, char *argv[])
{
    int numbers[7] = {0, 2, 4, 6, 8, 10, 12};
    
    mult2by2(numbers);
    
    printf("%d", numbers[2]);
}
