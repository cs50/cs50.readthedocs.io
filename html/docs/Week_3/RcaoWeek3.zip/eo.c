#include <cs50.h>
#include <stdio.h>

bool even (int n);
bool odd (int n);

int
main (int argc, char* argv[])
{
    printf("Int pl0x: \n");
    int numba = GetInt();
    
    if (odd(numba))
        printf("E!\n");
    else
        printf("O!\n");

}

bool
odd (int n)
{
    return (n==0) ? false : even(n-1);
}

bool 
even (int n)
{
    return (n==0) ? true : odd(n-1);
}

        

//(cond) ? (execute if true) : (execute if false);
//status = (computerOn) ? "online" : "offline";
