/****************************************
 * hash.h
 *
 * October 24, 2010
 * Doug Lloyd
 *
 * Constants and definitions for hash.c
 ****************************************/

// define hashtable size
#define TABLESIZE 22

// max word size
#define MAXSIZE 50
// nodes for separate chaining
typedef struct _node {
  char word[MAXSIZE];
  struct _node *next;
} node;

// hashtable
node *hashtable[TABLESIZE];

// calculates hash value of a given string
int hash(string x, int xlen);

// print the hashtable
void printhash(void);

// print individual rows
void printrow(node *x);
