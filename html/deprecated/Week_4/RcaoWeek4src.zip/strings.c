/***************************************************
*   Demonstrates pointer arithmetic and how an 
*   array name is simply a pointer to the first 
*   element of the array.
***********************************************@}~*/

#include <cs50.h>
#include <stdio.h>
#include <string.h>

int
main (int argc, char* argv[])
{
    printf("String pl0x:\n");
    char* str = GetString();
    
    int size = strlen(str);
    
    printf("\nWhat's inside...\n");
    
    printf("str: \033[36m%s\n\033[39m", str);
    printf("&str: \033[33m%p\n\n\033[39m", &str);

    // Print the individual chars and their addresses
    for (int i = 0; i < size; i++)
    {
        printf("*(str+%d): \033[36m%c\n\033[39m", i, *(str+i));    
        printf("&(*(str+%d)): \033[33m%p\n\n\033[39m", i, &(*(str+i)));
    }
    
    
    
/*
    printf("*str: %c\n", *str);
    printf("&(*str): 0x%x\n\n", &(*str));
    
    if (size > 1)
    {
        printf("*(str+1): %c\n", *(str+1));    
        printf("&(*(str+1)): 0x%x\n\n", &(*(str+1)));
    }
    
    if (size > 2)
    {
        printf("str[2]: %c\n", str[2]);
        printf("*(str+2): %c\n", *(str+2));
        printf("&(*(str+2)): 0x%x\n\n", &(*(str+2)));

    }
*/
}
