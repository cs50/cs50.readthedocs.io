/****************************************
 * hash.c
 *
 * October 24, 2010
 * Doug Lloyd
 *
 * Hash tables! 
 ****************************************/

#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "hash.h"

int main() {
  do {
    printf("Enter a string to add to the table. Enter \"--\" to stop: ");
    string w = GetString();
    if(!strncmp("--", w, 2))
      break;
    int wlen = strlen(w);
    node *new = malloc(sizeof(node));
    if(new == NULL)
      return 1;
    
    strncpy(new->word, w, wlen+1);

    int hashcode = hash(w, wlen);
    if(hashtable[hashcode] == NULL)
      hashtable[hashcode] = new;
    else {
      new->next = hashtable[hashcode];
      hashtable[hashcode] = new;
    }
    printhash();

  } while(true);

  return 0;
}

int hash(string x, int xlen) {
  int code = 0;
  for(int i = 0; i < xlen; i++)
    code += (int) x[i];
  return (code % TABLESIZE);
}

void printhash(void) {
  for(int i = 0; i < TABLESIZE; i++) {
    printf("[%2d] ", i);
    printrow(hashtable[i]);
    printf("\n");
  }
  return;
}

void printrow(node *x) {
  if(x == NULL)
    return;
  else {
    printf("-> %s ", x->word);
    printrow(x->next);
  }
  return;
}
