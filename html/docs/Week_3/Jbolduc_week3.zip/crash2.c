#include <stdio.h>
#include <stdlib.h>

int
main(int argc, char *argv[])
{
    int number = atoi(argv[1]);
    printf("You gave me the argument %d!\n", number);
    return 0;
}
