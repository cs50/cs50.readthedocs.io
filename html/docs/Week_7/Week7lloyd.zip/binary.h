// Tree node
typedef struct _tree {
  int data;
  struct _tree *left;
  struct _tree *right;
} tree;

// Print the tree
void printtree(tree *root);
void printtreeinorder(tree *root);
void printtreeshowparents(tree *root, int padding);


