#include <stdio.h>

void print_int(int number);

int main(int argc, char* argv[]) {
    // print the integer 5
    print_int(5);
    return 0;
}

/**
 * Print a number
 *
 */
void print_int(int number) {
    printf("Here's your number! %d\n", number);
}
