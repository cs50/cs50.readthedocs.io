#include <cs50.h>
#include <stdio.h>

int sum_digits (int num);

int
main (int argc, char* argv[])
{
    printf("Int pl0x:\n");
    int numba = GetInt();
    
    int sum = sum_digits(numba);
    printf("Sum is %d!\n", sum);    
}

int
sum_digits (int num)
{
    // Base case
    if (num/10 == 0)
        return num;
    // Recursing: (one's digit/remainder) + (num w/last digit cut off)
    else
        return num%10 + sum_digits(num/10);
}
