#include <stdio.h>

void add_ints(int x, int y);

int main(int argc, char* argv[]) {
    // add two numbers together
    int result = add_ints(23, 19);
    // display the result
    printf("%d\n", result);
}

int add_ints(int x, int y) {
    // add two numbers
    int z = x + y;
    // return the sum
    return z;
}
