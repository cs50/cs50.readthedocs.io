/************************************
*  Buggy swapping routine because   *
*  parameters are pass-by-value,    *
*  e.g. copies of the original      *
*  (that poof when swap() returns.  *
************************************/

#include <cs50.h>
#include <stdio.h>

void swap (int a, int b);

int
main (void)
{
    int x = 4;
    int y = 2;
    
    printf("Before x: %d, y: %d\n", x, y);
    swap(x, y);
    printf("After x: %d, y: %d\n", x, y);
}

void
swap (int a, int b)
{
    int temp = a;
    a = b;
    b = temp;
}
