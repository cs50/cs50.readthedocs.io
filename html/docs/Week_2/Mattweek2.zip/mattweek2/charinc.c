/******************************************************************************
 * charinc.c
 * Matthew Chartier
 * CS50/CSCI E-52
 *
 * What happens when we increment a char?
 *****************************************************************************/

#include <stdio.h>
#include <cs50.h>

int main (int argc, char* argv[])

{
    char c = 'A';
    c++;
    printf("%c\n", c);
}
