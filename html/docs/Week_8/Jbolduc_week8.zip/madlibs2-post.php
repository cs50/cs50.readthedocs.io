<?php
if (!isset($_POST['word0']))
{
    header("Location: madlibs2.php");
}

require_once('../../constants.php');
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
mysql_select_db(DB_NAME);

$now = time();
for ($i = 0; $i < 5; $i++)
{
    $word_db[$i] = mysql_real_escape_string($_POST['word' . $i]);
}
mysql_query("INSERT INTO madlibs (time_submitted, word0, word1, word2, word3, word4) VALUES ($now, '$word_db[0]', '$word_db[1]', '$word_db[2]', '$word_db[3]', '$word_db[4]')");

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Madlibs</title>
    </head>
    <body>
    <p>CS50 is a <?php echo $_POST['word0']; ?> course. The <?php echo $_POST['word1']; ?>, David Malan, is very <?php echo $_POST['word2']; ?>. All <?php echo $_POST['word3']; ?> should take CS50 before they <?php echo $_POST['word4']; ?>.</p>
    </body>
</html>
