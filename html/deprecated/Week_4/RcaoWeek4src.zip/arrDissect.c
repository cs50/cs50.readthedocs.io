/****************************************************
*   Asks for either a string or ints, depending on 
*   command-line argument and prints
*   each of the elements along with their addresses.
*
*   Notice how each element increases the address
*   by the size of the element's type.
*       (e.g. char: 1 byte, int: 4 bytes)
*
*   Prints the pointer's address to show it doesn't
*   change.
************************************************@}~*/

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_INTS 100
#define INT 0
#define STR 1

int checkType(char* arg);


int
main (int argc, char* argv[])
{
    if (argc < 2)
    {
        printf("\033[31mUsage: ./arrDissect dataType [0 to not print pointer address]\n\033[39m");
        return 1;
    }
    
    // See if the user wants to print ptr address later
    bool address = true;
    if (argc == 3 && atoi(argv[2]) == 0)
        address = false;
       
    
    int type = checkType(argv[1]);
    
    // Sanity check
    if (type < 0)
        return 2;

    int len;
    char* str;
    int arrNum[MAX_INTS];

    printf("What would you like to dissect?\n");
    if (type == STR)
    {
        str = GetString();
        len = strlen(str);
    }

    else if (type == INT)
    {
        // Continuously ask for ints to put into array
        for (len = 0; len < MAX_INTS; len++)
        {
            printf("arrInt[%d]: ", len);

            int curr = GetInt();
            if (curr == INT_MAX)
                break;
            arrNum[len] = curr;
        }
        printf("\n");
    }

    // Time to print
    char* typ = (type == INT) ? "int" : "char";
    printf("\n%s @ %sAddress\n", typ, typ);
    
    
    // Iterate through characters of string, analyzing
    for (int i = 0; i < len; i++)
    {
        if (type == STR)
        {
            // Use ANSI escape sequences for clarity...and coolness.
            printf("\033[33m%c @ %p\n", *(str+i), &(*(str+i)));
            
            if (address)
                printf("\033[36m                    Address of strPtr: %p\n", &str);
        }
        else if (type == INT)
        {
            printf("\033[33m%d @ %p\n", *(arrNum+i), &(*(arrNum+i)));

            if (address)
                printf("\033[36m                    Address of arrInt: %p\n", &arrNum);
        }
    }    
    printf("\033[39m\n");
}


/*
*  Function to parse command-line argument,
*  check whether we want to dissect an array of 
*  chars ("string") or of ints. 
*/
int 
checkType (char* arg)
{
    // Check for "int," the lazy way
    if (tolower(arg[0]) == 'i')
        return INT;
    else if (tolower(arg[0]) == 's')
        return STR;
    else
        return -1; //nonsensical val
}
