/*****************************************************************************
 * array1.c
 * Matthew Chartier
 * CS50/CSCI E-52
 *
 * Declares an array of ints of length 7 and allows user to query contents.
 *****************************************************************************/
 
#include <stdio.h>
#include <cs50.h>

int
main (int argc, char *argv[])
{
    int numbers[7];
    int index;
    
    while(1)
    {
        printf("Index: ");
        index = GetInt();
        printf("numbers[%d] == %d\n", index, numbers[index]);
    }
}
