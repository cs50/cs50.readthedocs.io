#include <cs50.h>
#include <stdio.h>

int mystery (int num1, int num2);

int
main (int argc, char* argv[])
{
    printf("First int, pl0x:\n");
    int numba1 = GetInt();

    printf("Second int, pl0x:\n");
    int numba2 = GetInt();
    
    int ret = mystery(numba1, numba2);
    printf("Returned: %d\n", ret);

}

int mystery(int num1, int num2)
{
    if (num2 == 0)
        return 1;
    else
        return num1 * mystery(num1, num2 - 1);
}
