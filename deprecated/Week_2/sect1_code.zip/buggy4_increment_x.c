#include <stdio.h>

int increment(int x);
int x;
int main()
{
    x = 1;
    int y = increment(x);
    
    printf(" %d %d \n", x, y);
}

int increment(int &x)
{
    x++;
    return x;
}
     
