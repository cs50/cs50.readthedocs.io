#include <stdio.h>

int main(int argc, char* argv[]) {
    // argv: array containing the program arguments
    for (int i = 0; i < argc; i++)
        printf("Argument %d: %s\n", i, argv[i]);
}
