#include <stdio.h>
#include "cs50.h"

float adder(float x, float y);
float avg (float sum, int n); 

int main()
{
    float x, y, sum;
    
    printf("\n Give me an x:");
    x = GetFloat();
    
    printf("\n Give me a y:");
    y = GetFloat();
    
    sum = adder (x, y);
    printf("\n Average: %f \n", avg(sum, 2));   
}    

float adder (float x, float y)
{
    return x+y;
}    

float avg(float sum, int n)
{
    return sum / n;
}
