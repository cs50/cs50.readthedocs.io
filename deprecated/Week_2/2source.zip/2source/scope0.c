/**************************************
*  With variable scope in mind,       *
*  what happens here? Why?            *
**************************************/


#include <cs50.h>
#include <stdio.h>

int
main (void)
{
    int cs = 61;
    printf("%d\n", cs); // to suppress compiler warning
    
    do
    {
        int cs = GetInt();
        printf("%d\n", cs);
    } while (cs > 50);

}
