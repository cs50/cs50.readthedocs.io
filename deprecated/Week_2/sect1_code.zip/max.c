//demo for ternary ?: operator

#include <stdio.h>
#include "cs50.h"

int max(int x, int y);

int main()
{
    int x, y;
    
    printf("\n Give me an int: ");
    x = GetInt();
    
    printf("\n Give me another int:");
    y = GetInt();
    
    printf("\n max is: %d \n", max(x,y));
}

int max(int x, int y)
{
    int greater;
    greater = (x > y ? x : y);
    
    return greater;
}
