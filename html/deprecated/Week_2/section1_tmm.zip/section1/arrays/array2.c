#include <stdio.h>

int main(int argc, char* argv[]) {
    // create new array
    char letters[5] = { 'm', 'a', 'l', 'a', 'n' };

    // what will this print?
    printf("%c\n", letters[1]);
}
