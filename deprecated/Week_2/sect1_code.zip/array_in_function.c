//pass by reference vs pass by value

#include <stdio.h>

//actually produces a change
void set_array(int array[])
{
    array[0] = 22;
}

//doesn't change the local a in main
void set_int(int x)
{
    x = 22;
}

int main()
{

    int a = 10;
    int b[4] = { 0, 1, 2, 3 };
    
    set_int(a);
    set_array(b);
    
    printf("%d %d \n", a, b[0]);
} 
  
