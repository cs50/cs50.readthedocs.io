#include<stdlib.h>
#include<stdio.h>

int main(int argc, char *argv[])
{
    if(argc != 2)
    {
        printf("Error: not enough arguments\n");
        return 1; //WHY?
    }
    
    int height = atoi(argv[1]);
    
    printf("\n %d \n", height); 
    
    //...
}
