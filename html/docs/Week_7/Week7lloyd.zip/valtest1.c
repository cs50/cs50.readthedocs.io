/*************************************
 * valtest1.c
 *
 * Doug Lloyd
 * October 24, 2010
 *
 * Will fail a valgrind check
 *************************************/

#include <stdio.h>
#include <stdlib.h>

int main() {
  int *x = malloc(sizeof(int));
  *x = 4;
  return 0;
}
