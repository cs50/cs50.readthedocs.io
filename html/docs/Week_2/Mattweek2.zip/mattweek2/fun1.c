/*****************************************************************************
 * fun1.c
 * Matthew Chartier
 * CS50/CSCI E-52
 *
 * Takes an int from the user and then squares(?) it using a function.
 *****************************************************************************/
 
#include <stdio.h>
#include <cs50.h>

void
square(int y)
{
     y = y * y;
}

int
main (int argc, char* argv[])
{
    //Get a positive integer from the user and store it in x.
    int x = GetInt();
    
    //Use a function to square the value in x!
    x = square(x);
    
    //Print out our new (squared?) value.
    printf("Your number squared is: %d\n", x);

    return 0;
}
