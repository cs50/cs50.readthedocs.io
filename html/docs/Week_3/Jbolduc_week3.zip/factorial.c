#include <stdio.h>
#include <stdlib.h>

int
factorial(int n)
{
    if (n == 1)
        return 1;
    return n * factorial(n-1);
}

int
main(int argc, char *argv[])
{
    if (argc < 2)
    {
        printf("usage: %s num\n", argv[0]);
        return 1;
    }
    int num = atoi(argv[1]);
    printf("%d\n", factorial(num));
    return 0;
}
