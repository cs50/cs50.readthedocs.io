<?php 
$word = array("Adjective",
               "Noun",
               "Adjective",
               "Plural noun",
               "Verb");

echo '<?xml version="1.0" encoding="utf-8"?>';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Madlibs</title>
    </head>
    <body>
<?php
    echo '<form method="post" action="madlibs2-post.php">';
    foreach ($word as $id => $type)
    {
        echo $type . ': <input type="text" name="word' . $id . '" /><br />';
    }
    echo '<input type="submit" name="submit" value="Submit madlib"! />';
    echo '</form>';
?>
    </body>
</html>
