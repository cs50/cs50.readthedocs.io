/****************************
 * Problem Set 2            *
 * oldman.c                 *
 *                          *
 * Doug Lloyd               *
 * September 21, 2011       *
 ****************************/

/* Constants */
#define VERSES 10

/* Header Files */
#include <stdio.h>
#include <cs50.h>

/* Function Declarations */
string where(int versenum);

/*****************************/

int main(int argc, char *argv[]) {

  /* Arrays to hold strings for verse number and locations */
  string nums[VERSES] = {"one", "two", "three", "four", "five",
			 "six", "seven", "eight", "nine", "ten"};
  string places[VERSES] = {"thumb", "shoe", "knee", "door", "hive",
			   "sticks", "heaven", "gate", "spine", "again"};

  /* Singing the song */
  for(int i = 0; i < VERSES; i++) {
    printf("This old man, he played %s\n", nums[i]);
    printf("He played knick-knack %s %s\n", where(i), places[i]);
    printf("Knick-knack, paddywhack, give your dog a bone\n");
    printf("This old man came rolling home\n\n");
  }

  return 0;
}

string where(int versenum) {
  
  /* Depending on the verse number, the sentence changes a little bit */
  switch(versenum) {
  case 6:
    return "up in";
    break;
  case 9:
    return "once";
    break;
  default:
    return "on my";
    break;
  }
  
  /* The program should never get here. */
  return "";
}
