#include <stdio.h>

int main(int argc, char* argv[]) {
    // argc: the number of arguments passed to the program
    printf("You passed me %d args!\n", argc);
}
