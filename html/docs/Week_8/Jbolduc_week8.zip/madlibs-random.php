<?php
require_once('../../constants.php');
mysql_connect(DB_SERVER, DB_USER, DB_PASS);
mysql_select_db(DB_NAME);

$result = mysql_query("SELECT * FROM madlibs ORDER BY RAND() LIMIT 1");
$word = mysql_fetch_array($result);

for ($i = 0; $i < 5; $i++)
{
    $word_html[$i] = htmlentities($word['word' . $i]);
}

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
        <title>Madlibs</title>
    </head>
    <body>
    <p>Posted <?php echo date('F j, Y \a\t n:i A', $word['time_submitted']); ?></p>
    <p>CS50 is a <?php echo $word_html[0]; ?> course. The <?php echo $word_html[1]; ?>, David Malan, is very <?php echo $word_html[2]; ?>. All <?php echo $word_html[3]; ?> should take CS50 before they <?php echo $word_html[4]; ?>.</p>
    </body>
</html>
