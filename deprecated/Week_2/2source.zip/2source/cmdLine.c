/*******************************************
*  Prints out the number of command-line   *
*  arguments (argc) and the arguments      *
*  themselves (argv[]).                    *
********************************************/

#include <cs50.h>
#include <stdio.h>

int
main (int argc, char* argv[])
{
    // For grammatical purposes
    string arg = (argc == 1) ? "argument" : "arguments";
    
    printf("You entered %d command-line %s!\nThey are:\n", argc, arg);
    
    // Iterate through argv, the array of command-line strings
    for(int i = 0; i < argc; i++)
    {
        // Printf each command-line argument on its own line
        printf("%s\n", argv[i]);
    }
}
