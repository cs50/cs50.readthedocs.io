/* Buggy vigenere to gdb */

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int checkKey(int len, string key);

int
main (int argc, char* argv[])
{
    // Check num of command-line arguments
    if (argc != 2)
    {
        printf("You forgot the keyword!\n");
        return 1;
    }

    string key = argv[1];
    int klen = strlen(key);
    
    // Check and normalize key w/function
    if(checkKey(klen, key))
        return 2;
        
    // Demand plaintxt
    printf("i can has plantxt [sik]?\n");
    string ptxt = GetString();
    
    int len = strlen(ptxt);
    char c;
    
    // Go through each char of plaintxt
    for (int i = 0; i < len; i++)
    {
        // If uppercase,
        if (ptxt[i] <= 'A' && ptxt[i] >= 'Z')
            c = (((ptxt[i] - 'A') + key[i]) % 26) + 'A';
        // If lowercase,
        else if (ptxt[i] <= 'a' && ptxt[i] >= 'z')
            c = (((ptxt[i] - 'a') + key[i]) % 26) + 'a';
        // Print it
        printf("%c", c);
    }
    printf("\n");
}

int
checkKey(int len, string key)
{
    // Make sure key is alpha only
    for (int i = 0; i < len; i++)
    {
        if (!isalpha(key[i]))
        {
            printf("Alpha keys only, pl0x.\n");
            return 1;
        }
        // If legit, normalize
        key[i] = toupper(key[i]) - 'A';
    }
    return 0;    
}
