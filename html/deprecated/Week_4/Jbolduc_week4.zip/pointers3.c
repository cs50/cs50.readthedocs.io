#include <stdio.h>

int
main(int argc, char *argv[])
{
    int array[] = {5, 10, 15, 20, 25};
    int *pa = array;
    
    printf("The value of array[0] is %d\n", array[0]);
    printf("The value of array is 0x%x\n", array);
    printf("The value of pa is 0x%x\n", (unsigned int) pa);
    printf("The value of *pa is %d\n", *pa);
    printf("The value of (pa + 1) is 0x%x\n", (unsigned int) (pa + 1));
    printf("The value of *(pa + 1) is %d\n", *(pa + 1));
    printf("The value of (array + 1) is 0x%x\n", (unsigned int) (array + 1));
    printf("The value of *(array + 1) is %d\n", *(array + 1));

    return 0;
}
